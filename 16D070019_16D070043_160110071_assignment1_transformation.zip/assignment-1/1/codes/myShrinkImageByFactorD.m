function shrinkImage = myShrinkImageByFactorD(orgImage,d)
    shrinkImage = orgImage(1:d:end,1:d:end);
end
